<!DOCTYPE html>
<html>
<head>
	<title>me link</title>
	<link rel="stylesheet" type="text/css" href="css/link.css">
</head>
<body>
	<div class="link">
		<div class="common">
		<div class="branch">
			<h3>FIRST SEMESTER</h3>
		<div class="subject_name">
			1.1<a href="diploma\common\physic.pdf" class="subject_content">Foundational Communication</a><br>
			1.2<a href="diploma\common\physic.pdf" class="subject_content">Applied Mathematics-I </a><br>
			1.2<a href="diploma\common\physic.pdf" class="subject_content">Applied Mathematics-I </a><br>
			1.2<a href="diploma\common\physic.pdf" class="subject_content">Applied Mathematics-I </a><br>
			1.2<a href="diploma\common\physic.pdf" class="subject_content">Applied Mathematics-I </a><br>
			1.2<a href="diploma\common\physic.pdf" class="subject_content">Applied Mathematics-I </a><br>
			1.3<a href="diploma\common\physic.pdf" class="subject_content">Applied Physics-I </a><br>
			1.4<a href="diploma\common\physic.pdf" class="subject_content">Applied Chemistry</a><br>
			1.5<a href="diploma\common\physic.pdf" class="subject_content">Engineering Drawing-I </a><br>
			
		</div>	
		</div>

		<div class="branch">
			<h3>SECOND SEMESTER</h3>
		<div class="subject_name">
			2.1<a href="diploma\common\physic.pdf" class="subject_content">Applied Mathematics-II </a><br>
			2.2<a href="diploma\common\physic.pdf" class="subject_content"> Applied Physics-II</a><br>
			2.3<a href="diploma\common\physic.pdf" class="subject_content"> Applied Mechanics</a><br>
			2.4<a href="diploma\common\physic.pdf" class="subject_content">Basics of Mechanical and Electrical Engg. </a><br>
			2.5<a href="diploma\common\physic.pdf" class="subject_content">Elementary Workshop Tech.</a>
		</div>
			
		</div>
	</div>
	<div class="common">

		<div class="branch">
			<h3>THIRD SEMESTER</h3>
		<div class="subject_name">
			3.1<a href="diploma\common\physic.pdf" class="subject_content">FunctionalCommunication</a><br>
			3.2<a href="diploma\common\physic.pdf" class="subject_content">Applied Mathematics-II </a><br>
			3.3<a href="diploma\common\physic.pdf" class="subject_content">Materials & Material Science</a><br>
			3.4<a href="diploma\common\physic.pdf" class="subject_content">Thermal Engineering</a><br>
			3.5<a href="diploma\common\physic.pdf" class="subject_content"> Manufacturing Processes</a><br>
			3.6<a href="diploma\common\physic.pdf" class="subject_content"> Introduction To Computer Practicals</a>
		</div>
		</div>

		<div class="branch">
			<h3>FOURTH SEMESTER</h3>
		<div class="subject_name">
			4.1<a href="diploma\common\physic.pdf" class="subject_content">Mechanics of Solids</a><br>
			4.2<a href="diploma\common\physic.pdf" class="subject_content">Hydraulics & Hydraulic Machines</a><br>
			4.3<a href="diploma\common\physic.pdf" class="subject_content"> Electrical Technology & Electronics</a><br>
			4.4<a href="diploma\common\physic.pdf" class="subject_content"> Mechanical Engg. Drawing Practicals</a><br>
				
		</div>
		</div>
	</div>
	<div class="common">

		<div class="branch">
			<h3>FIFTH SEMESTER</h3>
		<div class="subject_name">
			5.1<a href="diploma\common\physic.pdf" class="subject_content"> Integrative Communication</a><br>
			5.2<a href="diploma\common\physic.pdf" class="subject_content"> Industrial Management and Entrepreneurship Development</a><br>
			5.3<a href="diploma\common\physic.pdf" class="subject_content"> Theory of Machines </a><br>
			5.4<a href="diploma\common\physic.pdf" class="subject_content"> M/c Tool Tech.& Maintenance</a><br>
			5.5<a href="diploma\common\physic.pdf" class="subject_content">Design & Estimation Practicals </a>
			
		</div>
		</div>

		<div class="branch">
			<h3>SIXTH SEMESTER</h3>
		<div class="subject_name">
			6.1<a href="diploma\common\physic.pdf" class="subject_content">Environmental Education and Disaster Management</a><br>
			6.2<a href="diploma\common\physic.pdf" class="subject_content">Industrial Engg.& Safety</a><br>
			6.3<a href="diploma\common\physic.pdf" class="subject_content">Metrology & Measuring Instruments Practicals </a>
			6.4<a href="diploma\common\physic.pdf" class="subject_content">Production Technology-II</a><br>
			6.5<a href="diploma\common\physic.pdf" class="subject_content">Software Application in Civil Engineering CNC Machine & Automation</a>
		</div>
			
		</div>
	</div>

	</div>

</body>
</html>