<!DOCTYPE html>
<html>
<head>
	<title>ee link</title>
	<link rel="stylesheet" type="text/css" href="css/link.css">
</head>
<body>
	<div class="link">
		<div class="common">
		<div class="branch">
			<h3>FIRST SEMESTER</h3>
		<div class="subject_name">
			1.1<a href="diploma\common\communication skill-1.pdf" class="subject_content">Communication Skills-1</a><br>
			1.2<a href="diploma\common\maths.pdf" class="subject_content">Applied Mathematics-I </a><br>
			1.3<a href="diploma\common\physic.pdf" class="subject_content">Applied Physics-I </a><br>
			1.4<a href="diploma\common\physic.pdf" class="subject_content">Applied Chemistry</a><br>
			1.5<a href="diploma\common\physic.pdf" class="subject_content">Engineering Drawing-I </a><br>
			1.6<a href="diploma\common\physic.pdf" class="subject_content">Basics of Information Technology</a>
		</div>	
		</div>

		<div class="branch">
			<h3>SECOND SEMESTER</h3>
		<div class="subject_name">
			2.1<a href="diploma\common\physic.pdf" class="subject_content">Applied Mathematics-II </a><br>
			2.2<a href="diploma\common\physic.pdf" class="subject_content">Applied Physics-II</a><br>
			2.3<a href="diploma\common\physic.pdf" class="subject_content">Basic Electrical Engineering </a><br>
			2.4<a href="diploma\common\physic.pdf" class="subject_content">Basics of Mechanical and Civil Engineering </a><br>
			2.5<a href="diploma\common\physic.pdf" class="subject_content">Analog Electronics</a>
		</div>
			
		</div>
	</div>
	<div class="common">

		<div class="branch">
			<h3>THIRD SEMESTER</h3>
		<div class="subject_name">
			3.1<a href="" class="subject_content">Applied Mathematics -III </a><br>
			3.2<a href="diploma\common\physic.pdf" class="subject_content">Electrical Instrumentation and Measurement </a><br>
			3.3<a href="diploma\common\physic.pdf" class="subject_content">Electrical and Electronics Engineering Materials</a><br>
			3.4<a href="diploma\common\physic.pdf" class="subject_content">Digital Electronics </a><br>
			3.5<a href="diploma\common\physic.pdf" class="subject_content">Electrical Machine - I</a><br>
			3.6<a href="diploma\common\physic.pdf" class="subject_content">Environmental Studies</a>
		</div>
		</div>

		<div class="branch">
			<h3>FOURTH SEMESTER</h3>
		<div class="subject_name">
			4.1<a href="diploma\common\physic.pdf" class="subject_content">Communication Skill-II</a><br>
			4.2<a href="diploma\common\physic.pdf" class="subject_content">Industrial Electronics and Control</a><br>
			4.3<a href="diploma\common\physic.pdf" class="subject_content">Electrical Design, Drawing and Estimating-I </a><br>
			4.4<a href="diploma\common\physic.pdf" class="subject_content">Power Plant Engineering</a><br>
			4.5<a href="diploma\common\physic.pdf" class="subject_content">Transmission and Distribution of Electrical Power</a><br>
			4.6<a href="diploma\common\physic.pdf" class="subject_content">Energy Conservation</a>	
		</div>
		</div>
	</div>
	<div class="common">

		<div class="branch">
			<h3>FIFTH SEMESTER</h3>
		<div class="subject_name">
			5.1<a href="diploma\common\physic.pdf" class="subject_content">Industrial Management and Entrepreneurship Development</a><br>
			5.2<a href="diploma\common\physic.pdf" class="subject_content">Switchgear and Protection </a><br>
			5.3<a href="diploma\common\physic.pdf" class="subject_content">PLC, Microcontroller and SCADA</a><br>
			5.4<a href="diploma\common\physic.pdf" class="subject_content">Electrical Machine – II</a>
		</div>
		</div>

		<div class="branch">
			<h3>SIXTH SEMESTER</h3>
		<div class="subject_name">
			6.1<a href="diploma\common\physic.pdf" class="subject_content">Installation, Maintenance and Repair of Electrical Equipment</a><br>
			6.2<a href="diploma\common\physic.pdf" class="subject_content">Electrical Design, Drawing and Estimating II </a><br>
			6.3<a href="diploma\common\physic.pdf" class="subject_content">Utilization of Electrical Energy </a>
			6.4<a href="diploma\common\physic.pdf" class="subject_content">Application of Computer Software in Electrical Engineering</a>
		</div>
			
		</div>
	</div>

	</div>

</body>
</html>